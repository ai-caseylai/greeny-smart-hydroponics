#!/usr/bin/env python3
"""Greeny Control Script - Execute control operations on the Greeny hydroponic system."""

import argparse
import json
import os
import sys
import urllib.request
import urllib.error


def get_api_config():
    """Get API URL and token from environment."""
    api_url = os.environ.get('GREENY_API_URL', 'https://greeny.techforliving.net/api')
    token = os.environ.get('GREENY_API_TOKEN', '')
    if not token:
        username = os.environ.get('GREENY_USERNAME', 'admin')
        password = os.environ.get('GREENY_PASSWORD', 'admin123')
        token = login(api_url, username, password)
    return api_url.rstrip('/'), token


def login(api_url, username, password):
    """Login and get JWT token."""
    data = json.dumps({"username": username, "password": password}).encode()
    req = urllib.request.Request(
        f"{api_url}/auth/login",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req) as resp:
            result = json.loads(resp.read())
            token = result.get("token", "")
            if token:
                os.environ['GREENY_API_TOKEN'] = token
            return token
    except urllib.error.HTTPError as e:
        print(json.dumps({"error": f"Login failed: {e.code}"}), file=sys.stderr)
        sys.exit(1)


def api_request(api_url, token, path, method="POST", body=None):
    """Make authenticated API request."""
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(
        f"{api_url}{path}",
        data=data,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        },
        method=method
    )
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read()) if resp.length else {"ok": True}
    except urllib.error.HTTPError as e:
        error_body = e.read().decode()
        if e.code == 401:
            token = login(api_url,
                         os.environ.get('GREENY_USERNAME', 'admin'),
                         os.environ.get('GREENY_PASSWORD', 'admin123'))
            req = urllib.request.Request(
                f"{api_url}{path}",
                data=data,
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                method=method
            )
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read()) if resp.length else {"ok": True}
        print(json.dumps({"error": f"HTTP {e.code}", "message": error_body}), file=sys.stderr)
        sys.exit(1)


def cmd_acknowledge(args):
    """Acknowledge an alert."""
    api_url, token = get_api_config()
    result = api_request(api_url, token, f"/alerts/{args.alert_id}", method="PATCH",
                        body={"acknowledged": 1})
    print(json.dumps({"ok": True, "alert_id": args.alert_id, "action": "acknowledged"}))


def cmd_run_automation(args):
    """Trigger an automation task."""
    api_url, token = get_api_config()
    result = api_request(api_url, token, f"/automations/{args.id}/run", method="POST")
    print(json.dumps({"ok": True, "automation_id": args.id, "action": "triggered"}))


def cmd_add_vegetable(args):
    """Add a vegetable record to a rack."""
    api_url, token = get_api_config()
    body = {
        "rack_id": args.rack_id,
        "layer_number": args.layer,
        "variety": args.variety,
        "quantity": args.quantity,
    }
    result = api_request(api_url, token, "/rack-vegetables", body=body)
    print(json.dumps({"ok": True, "action": "vegetable_added", "rack_id": args.rack_id}))


def cmd_add_environment(args):
    """Add an environment record for a rack."""
    api_url, token = get_api_config()
    body = {"rack_id": args.rack_id}
    if args.temperature is not None:
        body["temperature"] = args.temperature
    if args.humidity is not None:
        body["humidity"] = args.humidity
    if args.light_level is not None:
        body["light_level"] = args.light_level
    if args.ph is not None:
        body["ph"] = args.ph
    if args.ec is not None:
        body["ec"] = args.ec
    result = api_request(api_url, token, "/rack-environment", body=body)
    print(json.dumps({"ok": True, "action": "environment_recorded", "rack_id": args.rack_id}))


def cmd_notify(args):
    """Send WhatsApp notification via WorkBuddy proxy."""
    api_url, token = get_api_config()
    body = {
        "phone": args.phone,
        "message": args.message,
    }
    result = api_request(api_url, token, "/workbuddy/send-whatsapp", body=body)
    print(json.dumps({"ok": True, "action": "notification_sent", "phone": args.phone}))


def cmd_create_user(args):
    """Create a new user."""
    api_url, token = get_api_config()
    body = {
        "username": args.username,
        "password": args.password,
        "role": args.role or "staff",
        "display_name": args.display_name or "",
    }
    if args.office_id:
        body["office_id"] = args.office_id
    result = api_request(api_url, token, "/users", body=body)
    print(json.dumps({"ok": True, "action": "user_created", "username": args.username}))


def cmd_toggle_automation(args):
    """Enable or disable an automation."""
    api_url, token = get_api_config()
    result = api_request(api_url, token, f"/automations/{args.id}", method="PUT",
                        body={"enabled": args.enabled})
    print(json.dumps({"ok": True, "automation_id": args.id, "enabled": args.enabled}))


def cmd_add_crop(args):
    """Add a new crop batch (seedling entry)."""
    api_url, token = get_api_config()
    body = {
        "variety": args.variety,
        "quantity": args.quantity or 0,
        "unit": "株",
        "expected_harvest_days": args.days or 10,
    }
    if args.office_id:
        body["office_id"] = args.office_id
    if args.rack_id:
        body["rack_id"] = args.rack_id
    result = api_request(api_url, token, "/crop-batches", body=body)
    print(json.dumps({"ok": True, "action": "crop_planted", "variety": args.variety}))


def cmd_harvest(args):
    """Record a harvest."""
    api_url, token = get_api_config()
    body = {
        "batch_id": args.batch_id,
        "quantity": args.quantity,
        "unit": "株",
        "quality": args.quality or "good",
        "notes": args.notes or "",
    }
    result = api_request(api_url, token, "/harvests", body=body)
    print(json.dumps({"ok": True, "action": "harvest_recorded", "batch_id": args.batch_id, "quantity": args.quantity}))


def cmd_reset_password(args):
    """Reset a user's password."""
    api_url, token = get_api_config()
    result = api_request(api_url, token, f"/users/{args.user_id}", method="PATCH",
                        body={"password": args.new_password})
    print(json.dumps({"ok": True, "action": "password_reset", "user_id": args.user_id}))


def main():
    parser = argparse.ArgumentParser(description="Greeny Hydroponic System Control Tool")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # acknowledge
    p = subparsers.add_parser("acknowledge", help="Acknowledge an alert")
    p.add_argument("--alert_id", type=int, required=True, help="Alert ID")
    p.set_defaults(func=cmd_acknowledge)

    # run_automation
    p = subparsers.add_parser("run_automation", help="Trigger an automation")
    p.add_argument("--id", type=int, required=True, help="Automation ID")
    p.set_defaults(func=cmd_run_automation)

    # add_vegetable
    p = subparsers.add_parser("add_vegetable", help="Add vegetable to rack")
    p.add_argument("--rack_id", type=int, required=True, help="Rack ID")
    p.add_argument("--layer", type=int, required=True, help="Layer number")
    p.add_argument("--variety", required=True, help="Vegetable variety")
    p.add_argument("--quantity", type=int, default=1, help="Quantity")
    p.set_defaults(func=cmd_add_vegetable)

    # add_environment
    p = subparsers.add_parser("add_environment", help="Record environment data")
    p.add_argument("--rack_id", type=int, required=True, help="Rack ID")
    p.add_argument("--temperature", type=float, help="Temperature (°C)")
    p.add_argument("--humidity", type=float, help="Humidity (%)")
    p.add_argument("--light_level", type=float, help="Light level (lux)")
    p.add_argument("--ph", type=float, help="pH value")
    p.add_argument("--ec", type=float, help="EC value (μS)")
    p.set_defaults(func=cmd_add_environment)

    # notify
    p = subparsers.add_parser("notify", help="Send WhatsApp notification")
    p.add_argument("--phone", required=True, help="Phone number (e.g., 85291234567)")
    p.add_argument("--message", required=True, help="Message text")
    p.set_defaults(func=cmd_notify)

    # create_user
    p = subparsers.add_parser("create_user", help="Create a new user")
    p.add_argument("--username", required=True, help="Username")
    p.add_argument("--password", required=True, help="Password")
    p.add_argument("--role", choices=["superadmin", "office_admin", "staff"], help="Role")
    p.add_argument("--display_name", help="Display name")
    p.add_argument("--office_id", type=int, help="Office ID")
    p.set_defaults(func=cmd_create_user)

    # toggle_automation
    p = subparsers.add_parser("toggle_automation", help="Enable/disable automation")
    p.add_argument("--id", type=int, required=True, help="Automation ID")
    p.add_argument("--enabled", type=int, choices=[0, 1], required=True, help="1=enable, 0=disable")
    p.set_defaults(func=cmd_toggle_automation)

    # add_crop (seedling entry)
    p = subparsers.add_parser("add_crop", help="Add new seedling entry")
    p.add_argument("--variety", required=True, help="Crop variety (e.g. lettuce)")
    p.add_argument("--quantity", type=int, default=0, help="Quantity")
    p.add_argument("--days", type=int, default=10, help="Expected harvest days")
    p.add_argument("--office_id", type=int, help="Office ID")
    p.add_argument("--rack_id", type=int, help="Rack ID")
    p.set_defaults(func=cmd_add_crop)

    # harvest
    p = subparsers.add_parser("harvest", help="Record a harvest")
    p.add_argument("--batch_id", type=int, required=True, help="Crop batch ID")
    p.add_argument("--quantity", type=int, required=True, help="Harvest quantity")
    p.add_argument("--quality", choices=["excellent", "good", "fair", "poor"], default="good", help="Quality rating")
    p.add_argument("--notes", help="Notes")
    p.set_defaults(func=cmd_harvest)

    # reset_password
    p = subparsers.add_parser("reset_password", help="Reset user password")
    p.add_argument("--user_id", type=int, required=True, help="User ID")
    p.add_argument("--new_password", required=True, help="New password")
    p.set_defaults(func=cmd_reset_password)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
