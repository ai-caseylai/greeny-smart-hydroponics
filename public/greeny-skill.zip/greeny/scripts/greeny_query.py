#!/usr/bin/env python3
"""Greeny Query Script - Query hydroponic system data via Greeny API."""

import argparse
import json
import os
import sys
import urllib.request
import urllib.error


def get_api_config():
    """Get API URL and token from environment."""
    api_url = os.environ.get('GREENY_API_URL', 'https://greeny.techforliving.net/api')
    token = os.environ.get('GREENY_API_TOKEN', '')
    if not token:
        # Try to login with default credentials
        username = os.environ.get('GREENY_USERNAME', 'admin')
        password = os.environ.get('GREENY_PASSWORD', 'admin123')
        token = login(api_url, username, password)
    return api_url.rstrip('/'), token


def login(api_url, username, password):
    """Login and get JWT token."""
    data = json.dumps({"username": username, "password": password}).encode()
    req = urllib.request.Request(
        f"{api_url}/auth/login",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req) as resp:
            result = json.loads(resp.read())
            token = result.get("token", "")
            if token:
                os.environ['GREENY_API_TOKEN'] = token
            return token
    except urllib.error.HTTPError as e:
        print(json.dumps({"error": f"Login failed: {e.code}", "message": e.read().decode()}), file=sys.stderr)
        sys.exit(1)


def api_get(api_url, token, path, params=None):
    """Make authenticated GET request."""
    url = f"{api_url}{path}"
    if params:
        query = "&".join(f"{k}={v}" for k, v in params.items() if v is not None)
        if query:
            url += f"?{query}"

    req = urllib.request.Request(url, headers={
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    })
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        error_body = e.read().decode()
        if e.code == 401:
            # Token expired, try re-login
            token = login(api_url,
                         os.environ.get('GREENY_USERNAME', 'admin'),
                         os.environ.get('GREENY_PASSWORD', 'admin123'))
            req = urllib.request.Request(url, headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            })
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read())
        print(json.dumps({"error": f"HTTP {e.code}", "message": error_body}), file=sys.stderr)
        sys.exit(1)


def cmd_devices(args):
    """Query device status."""
    api_url, token = get_api_config()
    params = {}
    if args.office_id:
        params["office_id"] = args.office_id
    data = api_get(api_url, token, "/devices", params)
    print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_telemetry(args):
    """Query telemetry data."""
    api_url, token = get_api_config()
    params = {"limit": args.limit or 100}
    if args.device_id:
        params["device_id"] = args.device_id
    if args.office_id:
        params["office_id"] = args.office_id
    data = api_get(api_url, token, "/telemetry", params)
    print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_alerts(args):
    """Query alerts."""
    api_url, token = get_api_config()
    params = {}
    if args.status:
        params["acknowledged"] = "1" if args.status == "acknowledged" else "0"
    data = api_get(api_url, token, "/alerts", params)
    print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_racks(args):
    """Query racks."""
    api_url, token = get_api_config()
    params = {}
    if args.office_id:
        params["office_id"] = args.office_id
    data = api_get(api_url, token, "/racks", params)
    print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_vegetables(args):
    """Query vegetables for a rack."""
    api_url, token = get_api_config()
    params = {"rack_id": args.rack_id}
    data = api_get(api_url, token, "/rack-vegetables", params)
    print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_stats(args):
    """Query dashboard statistics."""
    api_url, token = get_api_config()
    params = {}
    if args.office_id:
        params["office_id"] = args.office_id
    data = api_get(api_url, token, "/dashboard/stats", params)
    print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_environment(args):
    """Query rack environment data."""
    api_url, token = get_api_config()
    params = {"rack_id": args.rack_id}
    data = api_get(api_url, token, "/rack-environment", params)
    print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_offices(args):
    """Query offices."""
    api_url, token = get_api_config()
    data = api_get(api_url, token, "/offices")
    print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_users(args):
    """Query users (admin only)."""
    api_url, token = get_api_config()
    data = api_get(api_url, token, "/users")
    print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_automations(args):
    """Query automations."""
    api_url, token = get_api_config()
    data = api_get(api_url, token, "/automations")
    print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_crops(args):
    """Query crop batches."""
    api_url, token = get_api_config()
    params = {}
    if args.office_id:
        params["office_id"] = args.office_id
    if args.status:
        params["status"] = args.status
    data = api_get(api_url, token, "/crop-batches", params)
    print(json.dumps(data, indent=2, ensure_ascii=False))


def cmd_harvests(args):
    """Query harvest logs."""
    api_url, token = get_api_config()
    params = {}
    if args.office_id:
        params["office_id"] = args.office_id
    if args.batch_id:
        params["batch_id"] = args.batch_id
    data = api_get(api_url, token, "/harvests", params)
    print(json.dumps(data, indent=2, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description="Greeny Hydroponic System Query Tool")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # devices
    p = subparsers.add_parser("devices", help="Query device status")
    p.add_argument("--office_id", type=int, help="Filter by office ID")
    p.set_defaults(func=cmd_devices)

    # telemetry
    p = subparsers.add_parser("telemetry", help="Query telemetry data")
    p.add_argument("--device_id", help="Filter by device ID")
    p.add_argument("--office_id", type=int, help="Filter by office ID")
    p.add_argument("--limit", type=int, default=100, help="Number of records (default 100)")
    p.set_defaults(func=cmd_telemetry)

    # alerts
    p = subparsers.add_parser("alerts", help="Query alerts")
    p.add_argument("--status", choices=["active", "acknowledged"], help="Filter by status")
    p.set_defaults(func=cmd_alerts)

    # racks
    p = subparsers.add_parser("racks", help="Query racks")
    p.add_argument("--office_id", type=int, help="Filter by office ID")
    p.set_defaults(func=cmd_racks)

    # vegetables
    p = subparsers.add_parser("vegetables", help="Query vegetables for a rack")
    p.add_argument("--rack_id", type=int, required=True, help="Rack ID")
    p.set_defaults(func=cmd_vegetables)

    # stats
    p = subparsers.add_parser("stats", help="Query dashboard statistics")
    p.add_argument("--office_id", type=int, help="Filter by office ID")
    p.set_defaults(func=cmd_stats)

    # environment
    p = subparsers.add_parser("environment", help="Query rack environment data")
    p.add_argument("--rack_id", type=int, required=True, help="Rack ID")
    p.set_defaults(func=cmd_environment)

    # offices
    p = subparsers.add_parser("offices", help="Query offices")
    p.set_defaults(func=cmd_offices)

    # users
    p = subparsers.add_parser("users", help="Query users (admin only)")
    p.set_defaults(func=cmd_users)

    # automations
    p = subparsers.add_parser("automations", help="Query automations")
    p.set_defaults(func=cmd_automations)

    # crops
    p = subparsers.add_parser("crops", help="Query crop batches")
    p.add_argument("--office_id", type=int, help="Filter by office ID")
    p.add_argument("--status", choices=["growing", "ready", "harvested", "failed"], help="Filter by status")
    p.set_defaults(func=cmd_crops)

    # harvests
    p = subparsers.add_parser("harvests", help="Query harvest logs")
    p.add_argument("--office_id", type=int, help="Filter by office ID")
    p.add_argument("--batch_id", type=int, help="Filter by batch ID")
    p.set_defaults(func=cmd_harvests)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
