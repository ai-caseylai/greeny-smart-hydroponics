# Greeny API Reference

Base URL: `https://greeny.techforliving.net/api`

Authentication: Bearer token in `Authorization` header (JWT from `/auth/login`)

## Authentication

### POST /auth/login
Login and get JWT token.
```json
// Request
{ "username": "admin", "password": "admin123" }

// Response
{ "token": "eyJ...", "user": { "id": 1, "username": "admin", "role": "superadmin", "office_id": null, "display_name": "Super Admin" } }
```

### GET /auth/me
Get current user info. Requires auth.

## Dashboard

### GET /dashboard/stats
Get dashboard statistics.
- Query params: `office_id` (optional) - filter by office

Response:
```json
{
  "online_devices": 12,
  "total_devices": 15,
  "today_alerts": 3,
  "avg_ph": 6.3,
  "avg_temp": 24.8,
  "device_distribution": [{"status": "online", "count": 12}],
  "recent_alerts": [...]
}
```

## Devices

### GET /devices
List all devices.
- Query params: `office_id` (optional) - filter by office

### GET /devices/{id}
Get device by ID.

## Telemetry

### GET /telemetry
Get telemetry readings.
- Query params: `device_id`, `office_id`, `limit` (default 100)

### POST /telemetry
Submit telemetry data (no auth required for device POST).
```json
{ "device_id": "WSD-001", "ph": 6.5, "ec": 1200, "water_temp": 24.5, "do_value": 7.2, "water_level": 85 }
```

## Alerts

### GET /alerts
List alerts.
- Query params: `acknowledged` (0 or 1)

### PATCH /alerts/{id}
Acknowledge alert: `{"acknowledged": 1}`

## Offices

### GET /offices
List active offices.

### POST /offices
Create office: `{"name": "...", "contact_person": "...", "contact_phone": "...", "whatsapp_number": "..."}`

### PUT /offices/{id}
Update office.

### DELETE /offices/{id}
Soft-delete office.

## Racks

### GET /racks
List racks.
- Query params: `office_id` (optional)

### POST /racks
Create rack: `{"name": "...", "office_id": 1, "location": "...", "layer_count": 3, "device_id": "WSD-001"}`

### GET /racks/{id}
Get rack detail.

### PUT /racks/{id}
Update rack.

### DELETE /racks/{id}
Delete rack.

## Rack Vegetables

### GET /rack-vegetables
List vegetables.
- Query params: `rack_id` (required)

### POST /rack-vegetables
Add vegetable: `{"rack_id": 1, "layer_number": 2, "variety": "生菜", "quantity": 8}`

### PUT /rack-vegetables/{id}
Update vegetable.

### DELETE /rack-vegetables/{id}
Delete vegetable.

## Rack Environment

### GET /rack-environment
Get environment records (last 100).
- Query params: `rack_id` (required)

### POST /rack-environment
Record environment data: `{"rack_id": 1, "temperature": 24.5, "humidity": 65, "ph": 6.2}`

## Automations

### GET /automations
List automations.

### POST /automations
Create automation.

### PUT /automations/{id}
Update automation (e.g., `{"enabled": 0}`).

### DELETE /automations/{id}
Delete automation.

### POST /automations/{id}/run
Trigger automation run.

## Users

### GET /users
List users (superadmin/office_admin only).

### POST /users
Create user: `{"username": "...", "password": "...", "role": "staff", "office_id": 1}`

### PATCH /users/{id}
Update user.

### DELETE /users/{id}
Deactivate user.

## WorkBuddy

### POST /workbuddy/send-whatsapp
Send WhatsApp message: `{"phone": "85291234567", "message": "Hello"}`

### GET /workbuddy/status
Get WorkBuddy API status.

## Roles & Permissions

| Role | Access |
|------|--------|
| superadmin | All offices, user management, system settings |
| office_admin | Own office only, manage staff in own office |
| staff | Read-only own office data |

## Demo Accounts

| Username | Password | Role | Office |
|----------|----------|------|--------|
| admin | admin123 | superadmin | All |
| office1 | admin123 | office_admin | TechForLiving (#1) |
| staff1 | admin123 | staff | TechForLiving (#1) |
| office2 | admin123 | office_admin | GreenLife (#2) |
